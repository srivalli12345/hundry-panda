var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["7b21ab6e-ed78-4d40-bca7-ec5e8ebeaef1","fcae71df-665b-49f9-95fd-ec652f077427","fc8294e5-bf72-4dea-ab3a-fb6820d445b4","dc773466-c0f0-4146-aeb9-5d7a9b5e3510"],"propsByKey":{"7b21ab6e-ed78-4d40-bca7-ec5e8ebeaef1":{"name":"bg","sourceUrl":null,"frameSize":{"x":450,"y":447},"frameCount":1,"looping":true,"frameDelay":12,"version":"iGZsCiSR09Fzlou_zORYyKKyuSL82qZE","loadedFromSource":true,"saved":true,"sourceSize":{"x":450,"y":447},"rootRelativePath":"assets/7b21ab6e-ed78-4d40-bca7-ec5e8ebeaef1.png"},"fcae71df-665b-49f9-95fd-ec652f077427":{"name":"ball","sourceUrl":null,"frameSize":{"x":18,"y":18},"frameCount":1,"looping":true,"frameDelay":12,"version":"CV_U1dzwg9xRAJq_kawtTCGiMxRnxJo9","loadedFromSource":true,"saved":true,"sourceSize":{"x":18,"y":18},"rootRelativePath":"assets/fcae71df-665b-49f9-95fd-ec652f077427.png"},"fc8294e5-bf72-4dea-ab3a-fb6820d445b4":{"name":"paddle","sourceUrl":null,"frameSize":{"x":74,"y":27},"frameCount":1,"looping":true,"frameDelay":12,"version":"Em1A6qXBHnUvefhqmtxM6B3IHMN8O9XT","loadedFromSource":true,"saved":true,"sourceSize":{"x":74,"y":27},"rootRelativePath":"assets/fc8294e5-bf72-4dea-ab3a-fb6820d445b4.png"},"dc773466-c0f0-4146-aeb9-5d7a9b5e3510":{"name":"box","sourceUrl":null,"frameSize":{"x":68,"y":20},"frameCount":1,"looping":true,"frameDelay":12,"version":"GqeVnGo5uK5d9CVn9QIH6Ji4OvpN7eMd","loadedFromSource":true,"saved":true,"sourceSize":{"x":68,"y":20},"rootRelativePath":"assets/dc773466-c0f0-4146-aeb9-5d7a9b5e3510.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

 //creating pladdle and the ball
 var score=0;  
var sprite = createSprite(200,200,20,40);
sprite.setAnimation("bg");
var paddle=createSprite(200,380,100,29);
paddle.shapeColor="red";
paddle.setAnimation("paddle");
var ball=createSprite(200,200,20,20);
ball.shapeColor="blue";
ball.setAnimation("ball");
//first row of boxes
var box1 = createSprite(30, 75, 40, 20);
box1.setAnimation("box");
var box2 = createSprite(80, 75, 40, 20);
box2.setAnimation("box");
var box3 = createSprite(130, 75, 40, 20);
box3.setAnimation("box");
var box4 = createSprite(180, 75, 40, 20);
box4.setAnimation("box");
var box5 = createSprite(230, 75, 40, 20);
box5.setAnimation("box");
var box6 = createSprite(280, 75, 40, 20);
box6.setAnimation("box");
var box7 = createSprite(330, 75, 40, 20);
box7.setAnimation("box");
var box8 = createSprite(380, 75, 40, 20);
box8.setAnimation("box");
//second row of boxes
var box9 = createSprite(25, 95, 40, 20);
box9.setAnimation("box");
var box10 = createSprite(75, 95, 40, 20);
box10.setAnimation("box");
var box11 = createSprite(125,95 ,40, 20);              
box11.setAnimation("box");
var box12 = createSprite(175,95, 40, 20);
box12.setAnimation("box");
var box13 = createSprite(225,95 ,40, 20);
box13.setAnimation("box");
var box14 = createSprite(275,95, 40, 20);
box14.setAnimation("box");
var box15 = createSprite(325,95, 40, 20);
box15.setAnimation("box");
var box16 = createSprite(375,95, 40, 20);
box16.setAnimation("box");

var score=0;
fill("black");
text("SCORE:"+score,380,20);
var gamestate="serve";
function draw() {
 background("white");

  //display welcome text
    
      if(gamestate == "serve")
  {
    textSize(25);
    text("Welcome! Press Enter to start.",30,200);
    paddle.x=World.mouseX;
  // giving velocity for ball 
  if (keyDown("ENTER")) {
     ball.velocityX=3;
    ball.velocityY=4;
    gamestate="play";
  }
  }
  
  if(gamestate == "play")
  { paddle.x=World.mouseX;
 if(ball.isTouching(bottomEdge)||score==16){
  gamestate="end";
    }
   }
  
  if(gamestate == "end")
  {
    textSize(25);
    text("Game end.",100,200);
    ball.velocityX=0;
      ball.velocityY=0;
  } 
    //Moving the paddle with mouse along the x-axis
  
  
 
 //Making the ball bounceOff the paddle and three sides of canvas
  createEdgeSprites();
  ball.bounceOff(topEdge);
  ball.bounceOff(leftEdge);
  ball.bounceOff(rightEdge);
  ball.bounceOff(paddle);
//destroy the boxes when ball touches them
  if (ball.isTouching(box1)) {
    box1.destroy();
  score=score+1;
  }
if (ball.isTouching(box2)) {
    box2.destroy();
  score=score+1;
  playSound("assets/category_tap/game_bubble_pop_click.mp3");
  }
  if (ball.isTouching(box3)) {
    box3.destroy();
  score=score+1;
  playSound("assets/category_tap/game_bubble_pop_click.mp3");
  }
  if (ball.isTouching(box4)) {
    box4.destroy();
  score=score+1;
  playSound("assets/category_tap/game_bubble_pop_click.mp3");
  }
  if (ball.isTouching(box5)) {
    box5.destroy();
  score=score+1;
  playSound("assets/category_tap/game_bubble_pop_click.mp3");
  }
  if (ball.isTouching(box6)) {
    box6.destroy();
  score=score+1;
  playSound("assets/category_tap/game_bubble_pop_click.mp3");
  }
  if (ball.isTouching(box7)) {
    box7.destroy();
  score=score+1;
  playSound("assets/category_tap/game_bubble_pop_click.mp3");
  }
  if (ball.isTouching(box8)) {
    box8.destroy();
  score=score+1;
  playSound("assets/category_tap/game_bubble_pop_click.mp3");
  }
  if (ball.isTouching(box9)) {
    box9.destroy();
  score=score+1;
  playSound("assets/category_tap/game_bubble_pop_click.mp3");
  }
  if (ball.isTouching(box10)) {
    box10.destroy();
  score=score+1;
  playSound("assets/category_tap/game_bubble_pop_click.mp3");
  }
  if (ball.isTouching(box11)) {
    box11.destroy();
  score=score+1;
  playSound("assets/category_tap/game_bubble_pop_click.mp3");
  }
  if (ball.isTouching(box12)) {
    box12.destroy();
  score=score+1;
  playSound("assets/category_tap/game_bubble_pop_click.mp3");
  }
  if (ball.isTouching(box13)) {
    box13.destroy();
  score=score+1;
  playSound("assets/category_tap/game_bubble_pop_click.mp3");
  }
  if (ball.isTouching(box14)) {
    box14.destroy();
  score=score+1;
  playSound("assets/category_tap/game_bubble_pop_click.mp3");
    
  }if (ball.isTouching(box15)) {
    box15.destroy();
  score=score+1;
  playSound("assets/category_tap/game_bubble_pop_click.mp3");
  }
  
   if (ball.isTouching(box16)) {
    box16.destroy();
  score=score+1;
  playSound("assets/category_tap/game_bubble_pop_click.mp3");
  }

 
drawSprites();
}
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
